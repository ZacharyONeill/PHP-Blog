<?php
define('DB_SERVER','localhost');
define('DB_USER','zto7115');
define('DB_PASS','eagle1');
define('DB_DATABASE','zto7115');
?>