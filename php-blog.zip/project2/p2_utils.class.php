<?php
	class p2_utils {
		//define('PASS','12345');
		
		function createServiceSelection() { //creates the checkboxes for the rss feeds on the Admin page
			$howManySelected = 0;
			$dom = new DomDocument();
			$dom->load('rss_class.xml');
			$web = $dom->getElementsByTagName('web');
			$choices = $dom->getElementsByTagName('choice');
			$sub2 = '';
			if( isset($_POST['submitServ'])) 
			{
					
				if(constant("PASS") == $_POST['password3']) 
				{
					for($i=0;$i<$choices->length;$i++) 
					{
						if( isset($_POST["service$i"]) ) 
						{
							$howManySelected++;
							echo $_POST["service$i"];
							$choices->item($i)->setAttribute('selected', 'yes');
						}else 
						{
							$choices->item($i)->setAttribute('selected', 'no');
						}
						
					}
						
						
					if( $howManySelected <= 3 )
					{
						$sub2 .= "<p>Services Changed Successfully.</p>";
						$dom->save("rss_class.xml");
					}else 
					{
						$sub2 .= "<p>Too many services selected, please select less than 3 services.</p>";
					}
						
					
						
				}else 
				{
					$sub2 .= '<p>Incorrect Password</p>';		
				}
				
			}
			$sub = '<br/><br/><h4>Choose up to 3 of the following services:</h4>';
			$sub .= '<form action="/zto7115/539/project2/admin.php" method="POST">';

			for($i=0;$i<$choices->length;$i++) 
			{
				$items = $choices->item($i);
				$name = $items->getElementsByTagName('name')->item(0)->nodeValue;
				$link = $items->getElementsByTagName('url')->item(0)->nodeValue;
				$selected = $items->getAttribute('selected');
				
				if($selected == 'yes') 
				{
					//echo "Checkbox$i should be selected";
					$sub .= '<input type="checkbox" name="service' . $i . '" value=" ' . $link . '" checked="checked" >' . $name . '<br/>';
				}else 
				{
					$sub .= '<input type="checkbox" name="service' . $i . '" value="' . $link . '" >' . $name . '<br/>';
				}
			}

			$sub .= '<br/>
			<br/>
			<b>Password: </b><input type="password" name="password3" size="15" /><br/>
			
			<input type="reset" value="Reset" />
			<input type="submit" value="Submit Services" name="submitServ" />
			</form><br/>';
			
			
			
			
			
			$sub .= $sub2;
			return $sub;
		} 
		function displayServices() { //displays the rss feed items selected on Admin page.
			
			$howManySelected = 0;
			$dom = new DomDocument();
			$dom->load('rss_class.xml');
			$web = $dom->getElementsByTagName('web');
			$choices = $dom->getElementsByTagName('choice');
			$sub = "<div id='services'>";
			
					
				
					
				
			
			

			for($i=0;$i<$choices->length;$i++) 
			{
				$items = $choices->item($i);
				$name = $items->getElementsByTagName('name')->item(0)->nodeValue;
				$link = $items->getElementsByTagName('url')->item(0)->nodeValue;
				$selected = $items->getAttribute('selected');
				
				if($selected == 'yes') //if selected
				{
					$sub .= "<div class='serviceItem'>";
					//echo "Checkbox$i should be selected";
					//$sub .= '<input type="checkbox" name="service' . $i . '" value=" ' . $link . '" checked="checked" >' . $name . '</input><br/>';
					$sub .= "<h1>$name</h1></br>";
					
					$dom1 = new DomDocument();
					$dom1->load("$link");
					$item = $dom1->getElementsByTagName('item')->item(0);
					$title = $item->getElementsByTagName('title')->item(0)->nodeValue;
					$link1 = $item->getElementsByTagName('link')->item(0)->nodeValue;
					$description = $item->getElementsByTagName('description')->item(0)->nodeValue;
					$pubDate = $item->getElementsByTagName('pubDate')->item(0)->nodeValue;
					
					$sub .= "<h2><a href=" . $link1 . ">$title</a></h2></br> ";
					$sub .= "<p>$pubDate</p></br>";
					$sub .= "<h4>$description</h4></br>";
					$sub .= "</div>";
					
					
				}
			}

			$sub .= "</div>";
			
			return $sub;
		} 
		function createClassmateSelection()//creates the checkboxes of the classmates, and validates number of selected students
		{
			$howManySelected = 0;
			$dom = new DomDocument();
			$dom->load('rss_class.xml');
			$students = $dom->getElementsByTagName('student');
			$sub2 = '';
			if( isset($_POST['submitClassmates'])) 
			{
				
				if(constant("PASS") == $_POST['password4']) //if password correct
				{
					for($i=0;$i<$students->length;$i++) //for every student
					{
						if( isset($_POST["student$i"]) ) 
						{
							$howManySelected++;
							$students->item($i)->setAttribute('selected', 'yes');
						}else 
						{
							$students->item($i)->setAttribute('selected', 'no');
						}
						
					}
						
						
					if( $howManySelected <= 10 ) 
					{
						$sub2 .= "<p>Classmate\s Feeds Changed Successfully.</p>";
						$dom->save("rss_class.xml");
					}else 
					{
						$sub2 .= "<p>Too many students selected, please select less than 10 student\'s feeds.</p>";
					}
						
						
					
						
				}else 
				{
					$sub2 .= '<p>Incorrect Password</p>';		
				}
				
			}

			$sub = '<br/><br/><h4>Choose up to 10 of the following student\'s feeds:</h4>';
			$sub .= '<form action="/zto7115/539/project2/admin.php" method="POST">';

			for($i=0;$i<$students->length;$i++) 
			{
				$firstName = $students->item($i)->getElementsByTagName('first')->item(0)->nodeValue;
				$lastName = $students->item($i)->getElementsByTagName('last')->item(0)->nodeValue;
				$link = $students->item($i)->getElementsByTagName('url')->item(0)->nodeValue;
				
				$selected = $students->item($i)->getAttribute('selected');
				
				if($selected == 'yes') 
				{
					//echo "Checkbox$i should be selected";
					
					$sub .= '<input type="checkbox" name="student' . $i . '" value=" ' . $link . '" checked="checked" >' . $firstName . " " . $lastName . '<br/>';
				}else 
				{
					$sub .= '<input type="checkbox" name="student' . $i . '" value="' . $link . '" >' . $firstName . " " . $lastName . '<br/>';
				}
			}

			$sub .= '<br/>
			<br/>
			<b>Password: </b><input type="password" name="password4" size="15" /><br/>
			
			<input type="reset" value="Reset" />
			<input type="submit" value="Submit Services" name="submitClassmates" />
			</form><br/>';
			
			$sub .= $sub2;
			return $sub;
		
		
		
		}
		function displayClassmates() { //this displays the feeds of the classmates that were selected in Admin.
			
			
			$dom = new DomDocument();
			$dom->load('rss_class.xml');
			$news = $dom->getElementsByTagName('news')->item(0);
			$students = $news->getElementsByTagName('student');
			$sub = "<div id='students'>";
			
			

			for($i=0;$i<$students->length;$i++) //loop through students
			{
				$items = $students->item($i);
				$first = $items->getElementsByTagName('first')->item(0)->nodeValue;
				$last = $items->getElementsByTagName('last')->item(0)->nodeValue;
				$name = "$first " . "$last";
				$link = $items->getElementsByTagName('url')->item(0)->nodeValue;
				$selected = $items->getAttribute('selected');
				
				if($selected == 'yes') //if selected
				{
					//echo "Checkbox$i should be selected";
					//$sub .= '<input type="checkbox" name="service' . $i . '" value=" ' . $link . '" checked="checked" >' . $name . '</input><br/>';
					$sub .= "<h1>$name</h1></br>";
					
					$dom1 = new DomDocument();
					$dom1->load("$link");
					$item = @$dom1->getElementsByTagName('item')->item(0);
					$title = @$item->getElementsByTagName('title')->item(0)->nodeValue;
					$link1 = @$item->getElementsByTagName('link')->item(0)->nodeValue;
					$description = @$item->getElementsByTagName('description')->item(0)->nodeValue;
					$pubDate = @$item->getElementsByTagName('pubDate')->item(0)->nodeValue;
					$item2 = @$dom1->getElementsByTagName('item')->item(1);
					$title2 = @$item2->getElementsByTagName('title')->item(0)->nodeValue;
					$link2 = @$item2->getElementsByTagName('link')->item(0)->nodeValue;
					$description2 = @$item2->getElementsByTagName('description')->item(0)->nodeValue;
					$pubDate2 = @$item2->getElementsByTagName('pubDate')->item(0)->nodeValue;
					
					$sub .= "<h2> <a href=" . $link1 . ">$title</a></h2></br>";
					$sub .= "<p>$pubDate</p></br>";
					$sub .= "<h4>$description</h4></br>";
					
					
					$sub .= "<h2> <a href=" . $link2 . ">$title2</a></h2></br>";
					$sub .= "<p>$pubDate2</p></br>";
					$sub .= "<h4>$description2</h4></br>";
					
					
					
				}
			}

			
			$sub .= "</div>";
			
			return $sub;
		}
					
		function permalink($postid="", $array="", $page="") //function to help create the permaLinks. postid is the post id of the link that was clicked, array is to help search through the same array to find the right article, and page also determines what post is displayed
		{
			$theArray = $array;
			$theIndex = $postid;
			$sub = '';
			$sub .= "<h2>" . $theArray[$theIndex]['subj'] . "</h2>";
			$sub .= "<h4>" . $theArray[$theIndex]['date'] . "</h4>";
				
			$clean = str_replace('&amp;lt;','<', $theArray[$theIndex]['body']); //long string-cleaning code
			$clean = str_replace('&amp;gt;','>', $clean);
			$clean = str_replace('&lt;','<', $clean);
			$clean = str_replace('&gt;','>', $clean);
			$clean = str_replace('&amp;quot;','"', $clean);
			$clean = str_replace('&quot;','"', $clean);
			$sub2 = nl2br("$clean");
			$sub .= "<p>" .  $sub2 . "</p>";
			$sub .= "<a href='news.php?thepage=$page'>Back</a>";
				
			return $sub; //returns information about the post to be displayed
			
		}
	}	
		
		
		
		
		
		
		
	







?> 