<?php

	require_once 'LIB_project1.php';
	
	$string = '';
	$string .= html_header($title='The Daily Annual - News' , $styles='style.css');
	$picture = chooseBanner($file='banners.txt');
	$string .= createBanner($pic='./pictures/newspaper.jpg', $ad="$picture");
	$string .= navigation();

	$string .= createEditForm($file="editorial.xml");
	//$string .= endForm();
	$string .= createNewsForm($file="news.xml");
	//$string .= endForm();
	$utilClass = new p2_utils();
	$string .= $utilClass->createClassmateSelection();
	$string .= $utilClass->createServiceSelection();
	$string .= html_footer($text='And here is the footer');
	echo $string;
	
	/*the rest is my Project1 code for Admin...
	<?php

	require_once 'LIB_project1.php';
	$string = '';
	$string .= html_header($title='The Daily Annual - News' , $styles='style.css');
	$string .= createBanner($pic='./pictures/newspaper.jpg', $ad='./pictures/newspaper.jpg');
	$string .= navigation();

	$string .= createEditForm($file="editorial.txt");
	//$string .= endForm();
	$string .= createNewsForm($file="news.txt");
	//$string .= endForm();
	$string .= html_footer($text='And here is the footer');
	echo $string;
	?>
	
	*/
?>
