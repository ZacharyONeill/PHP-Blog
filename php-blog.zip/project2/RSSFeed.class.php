<?php
class rssFeed{
	function loadFeed(){
			$file = "news.xml";
			$dom = new DomDocument;
			$dom->load($file);
			$dom2 = new DomDocument;
			$dom2->load("project2.rss");
			
			$theNews = $dom->getElementsByTagName('post');
			$theChannels = $dom2->getElementsByTagName('channel');
			
			$count = $theNews->length;
			$rssNumber = 10;
			$rssNumber = ($count<$rssNumber) ? $count:$rssNumber;
			while($dom2->getElementsByTagName('item')->length>0)
			{
				$theChannels->item(0)->removeChild($theChannels->item(0)->lastChild);
				$dom2->save("project2.rss");
			}
			for($i=0; $i<$rssNumber; $i++)
			{
				$articles = $theNews->item(($count-$i)-1);
				$subject = $articles->getAttribute("subject");
				$date = $articles->getAttribute("date");
				$content = $articles->getElementsByTagName("content")->item(0)->nodeValue;
				
				$rssTitle = $dom2->createElement("title",$subject);
				$rssTime = $dom2->createElement("pubDate",$date);
				$rssDesc = $dom2->createElement("description", $content);
				$rssItem = $dom2->createElement("item");
				$rssLink = $dom2->createElement("link","http://people.rit.edu/zto7115/539/project2/news.php?thepage=1");
				
				$rssItem->appendChild($rssTitle);
				$rssItem->appendChild($rssTime);
				$rssItem->appendChild($rssDesc);
				$rssItem->appendChild($rssLink);
				$theChannels->item(0)->appendChild($rssItem);
				
				
				
				$dom2->save("project2.rss");
			}
		}
}
?>