	<?php
	define('PASS','12345');
	require_once("RSSFeed.class.php");
	require_once("p2_utils.class.php");
	function navigation() //this forms and creates the nav buttons common on every page
	{
		$string=<<<END
		
	<div class="menuBar">
	<a class="menuButton" href="index.php?thepage=1">Home</a>
	<a class="menuButton" href="news.php?thepage=1">News</a>
	<a class="menuButton" href="admin.php?1=1">Admin</a>
	<a class="menuButton" href="services.php">Services</a>
	
	</div>
	
END;
		return $string;
	}
	function chooseBanner($file='') // Argument $file takes in a file to be used
	{
		$f = file($file);
		foreach($f as $line) //read through each line in the file
		{
			list($pic,$count,$weight) = explode('|',$line);
			$banners[] = array('pic' => $pic, 'count' => $count, 'weight' => trim($weight));
		}
		foreach($banners as $key => $val) //populate the array
		{
			$picture[$key] = $val['pic'];
			$counter[$key] = $val['count'];
			$weighter[$key] = trim($val['weight']);
		}
		array_multisort($counter, SORT_ASC, $banners); //sort based on count ascending

		$banners[0]['count'] = $banners[0]['count'] + $banners[0]['weight'];
		$sub = '';
		for($i=0; $i<count($banners); $i++) 
		{
			$sub .= trim(implode('|',$banners[$i]));
			$sub .= "\n";

		}
		file_put_contents('banners.txt',$sub);
		return $banners[0]['pic']; //returns filepath for picture to be used.
	}

	/*
	function chooseBanner($file='') // Argument $file takes in a file to be used
	{
		
	$dom = new DomDocument();
	$dom->load($file);
	$theBanners = $dom->getElementsByTagName('banners');
	$count = $theBanners->length;
	
		for($i=0; $i<$count;$i++)
		{
			$aBanner = $theBanners->item($i);
			$link = $aBanner->GetAttribute('link');
			$weight = $aBanner->GetAttribute('weight');
			$shown = $aBanner->GetAttribute('shown');
			$banners[] = array('pic' => $link, 'count' => $shown, 'weight' => trim($weight));
			
			
			
		}

		
		
		foreach($banners as $key => $val) //populate the array
		{
			$picture[$key] = $val['pic'];
			$counter[$key] = $val['count'];
			$weighter[$key] = trim($val['weight']);
		}
		array_multisort($counter, SORT_ASC, $banners); //sort based on count ascending

		$banners[0]['count'] = $banners[0]['count'] + $banners[0]['weight'];
		$sub = '';
		for($i=0; $i<count($banners); $i++) 
		{
			$sub .= trim(implode('|',$banners[$i]));
			$sub .= "\n";

		}
		$newRecord->setAttribute('shown', $banners[0]['count'] );
		file_put_contents('banners.txt',$sub);
		return $banners[0]['pic']; //returns filepath for picture to be used.
	}
	*/
	function html_header($title="Untitled", $styles="") //creates the header with dynamic title and stylesheets
	{
		$string=<<<END
	<!DOCTYPE html>
	<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	
	
	<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>

	<title>$title</title>
	<link rel="stylesheet" href="$styles" type="text/css"  />
	
	</head>
	<body>
	
	
END;
		return $string; //returns the code that gets appended after most function calls, which creates the main php pages
	}
	function html_footer($text="") //creates the footer, with text being anything inputted when function is called.
	{
		$sub="";
	$sub .= '<div id="foot">';
	$sub .= '<p>';
	$sub .= $text;
	$sub .= '</p>';
	$ua = $_SERVER['HTTP_USER_AGENT'];
	
	
	if (stripos($ua, "Firefox")) { //if person is using firefox...
		$sub .= '<p>At least you use Firefox.</p>';
	} else {
		$sub .= '<p>not jumping on the Firefox bandwagon, huh?</p>';
	}
	if (stripos($ua, "Windows")) { //if using windows...
		$sub .= '<p>Ahhh, Windows. The superior OS.</p>';
	}
	if (stripos($ua, "Macintosh")) { //if using mac
		$sub .= '<p>LOL MAC USER!</p>';
	}
	if (stripos($ua, "Linux")) { //if using linux
		$sub .= 'echo "<p>People still use Linux?</p>"';
	}
	$sub .= '</div>';
	$sub .= '</body>';
	$sub .= '</html>';
	

		return $sub; //returns code to be placed in main php pages
	}
	
	function createBanner($pic="", $ad="") // takes picture and ad files and puts them into the Banner div
	{
		$string=<<<END
		
	
	<div id="bannerLogo">
	<img src="$pic" alt="Logo" />
	<div id="bannerAd"><img src="$ad" alt="ad"  /></div>
	</div>

	
END;
		return $string;
	}
	function createContent() //simply used to create the content div
	{
		$string=<<<END
		
	<div id="content">
	
END;
		return $string;
	}
	function createEditorial($pic="", $file="") //loads editorial picture and takes text from a file and inserts them into the editorial div
	{
		$sub = file_get_contents($file);
		$sub = nl2br($sub);
		$string=<<<END
		
	<div id="editorial">
	
	<p><img src="$pic" width="100%" height="25%" alt="Me" /></p>
	
	<p>
	$sub
	</p>
	
	</div>
	
END;
		return $string;
	}
	
	function createNews($display="", $file="", $page=1, $current="index") // $display is the number of items you want to display, and $file is the file it loads.
	{
		$dom = new DomDocument();
		$dom->load($file);
		$theNews = $dom->getElementsByTagName('post');
		$count = $theNews->length;
		$newsArray = "";
		for($i=0; $i<$count;$i++)
		{
			$aPost = $theNews->item($i);
			$subject = $aPost->GetAttribute('subject');
			$date = $aPost->GetAttribute('date');
			$content = $aPost->GetElementsByTagName('content')->item(0)->nodeValue;
			$newsArray[$i] = array('subj' => $subject, 'date' => $date, 'body' => $content);
			
			
			
		}
		
		$thePage = @$_GET["thepage"];
		
		$articles = $thePage-1;
			
		$articles = $articles*$display;
		
		$sub = '<div id="news">';
		
		$display = (count($newsArray)-$articles < $display) ? count($newsArray)-$articles : $display;
		foreach ($newsArray as $key => $row) 
		{
			$s[$key]  = $row['subj'];
			$t[$key] = $row['date'];
			$b[$key] = $row['body'];
		}
		$newsArray = array_reverse($newsArray); //to get the most current posts to display first
		
		if( isset($_GET["postid"]) && $current = 'news') {
			//$index = $_GET["postid"];
			$aPage = $_GET["thepage"];
			
			//echo "The Post is: $index" ;
			$mod = 0;
			if( $aPage != 1 )
			{
				$mod = ($aPage-1)*5;
			}
			
			//$x = $_GET["postid"]+$mod;
			$utilClass = new p2_utils();
			$sub .= $utilClass->permalink($_GET["postid"]+$mod, $newsArray, $aPage);
			
			
			
		}
		else {
			for($i = 0; $i < $display; $i++) //cleans up and allows for line breaks, also creates the info
			{
				
				$amount = $articles + $i;
				
				if($current == 'news') {
					
					$sub .= "<h2>" . "<a href='news.php?postid=$i&amp;thepage=$thePage'>" . $newsArray[$amount]['subj'] . "</a></h2>";
					
				} else {
					$sub .= "<h2>" . $newsArray[$amount]['subj'] . "</h2>";
				}
				$sub .= "<h4>" . $newsArray[$amount]['date'] . "</h4>";
				
				
				$clean = str_replace('&amp;lt;','<', $newsArray[$amount]['body']);
				$clean = str_replace('&amp;gt;','>', $clean);
				$clean = str_replace('&lt;','<', $clean);
				$clean = str_replace('&gt;','>', $clean);
				$clean = str_replace('&amp;quot;','"', $clean);
				$clean = str_replace('&quot;','"', $clean);
				$sub2 = nl2br("$clean");
				$sub .= "<p>" .  $sub2 . "</p>";
			}
			if($current == 'news') //if page is news
			{
				$pageNum = count($newsArray)/5;
				$round = ceil($pageNum);
			
					$sub .= '<p>';
					for($i=0;$i<$round;$i++) 
					{
						$i2 = $i+1;
						$sub .= '<a class="pageButtons" href="news.php?thepage=' . $i2 . '" >' . $i2 . '</a>';
					}
					$sub .= '</p>';
				
			}
		
		}
		$sub .= '</div>';
		
		return $sub;
	} 
		
	function endContent() //simply ends the content div
	{
		$string=<<<END
		
	</div>
	
END;
		return $string;
	}
	
	function createEditForm($file="") //creates the Edit form on the admin page, $file is the file it writes to.
	{
		$sub2 = '';
		if(isset($_POST['text']) && array_key_exists('submitEdit',$_POST) && strlen($_POST['text'])>0) //make sure all values are ok and fields filled in
		{
			
			if(constant("PASS") == $_POST['password1']) { //password is '12345'
				$theText = sanitizeString($_POST['text']);
				$sub2 .= "Your post has been made.";
				
				$dom = new DomDocument();
				$dom->load($file);
				$theRoot = $dom->getElementsByTagName('editorial');
				$theContent = $dom->getElementsByTagName('content');
				
				
				
				
				
				$conText = $dom->createTextNode("$theText");
				$theContent->item(0)->nodeValue = $theText;
				
				
				
				
				$dom->save("$file");
			
				
			}else {
				$sub2 .= '<p>Incorrect Entries or Password</p>';
				
			}
		
		}
		elseif(array_key_exists('submitEdit',$_POST)) {
			$sub2 .= '<p>Post not made. Make sure all fields are filled in.</p>';
		}
		$dom2 = new DomDocument();
		$dom2->load('editorial.xml');
		$editorial = $dom2->getElementsByTagName('content')->item(0)->nodeValue;
		$sub=<<<END
		<div id="meh">
		<h2>Admin</h2>
		<h3>Edit Editorial</h3>
		<form action = "/zto7115/539/project2/admin.php" method="post">

		<table>

			<tr>

				<td>

					<textarea style="font-size:18px;"  name="text" rows="10" cols="80">$editorial</textarea>

				</td>

			</tr>

		</table>

		
		<div class="work">
		<br />
		<strong>Password: </strong><input type="password" name="password1" size="15" /><br /><br />

		<input type="reset" value="Reset Form" />

		<input type="submit" name="submitEdit" value="Submit Changes" />
		</div>
		
		</form>

END;
		 
		
		
		
		
		$sub .= $sub2;
	return $sub;
	}
	function createNewsForm($file="") // creates the news form, $file is the file it writes to
	{
		$sub2 = '';
		if(isset($_POST['contentNews']) && isset($_POST['subjectNews'])&& array_key_exists('submitNews',$_POST) && strlen($_POST['subjectNews'])>0 && strlen($_POST['contentNews'])>0) 
		{
			
			if(constant("PASS") == $_POST['password2']) {
				$time=time();

				
				$thePost  = sanitizeString($_POST['subjectNews']);
				
				$theDate = date("F j, Y, g:i a", $time);
				$clean = sanitizeString($_POST['contentNews']) ;
				$clean = str_replace(chr(10), '<br />', $clean); //to help deal with line breaks
				$clean = str_replace(chr(13), '<br />', $clean);
				$theContent = sanitizeString($clean) . chr(10);
				$sub2 .= "Your post has been made.";
				
				
				$dom = new DomDocument();
				$dom->load($file);
				$thePosts = $dom->getElementsByTagName('news');
				$newPost = $dom->createElement('post');
				$newPost->setAttribute('subject', $thePost );
				$newPost->setAttribute('date', $theDate );
				//$topicVal = $dom->createTextNode( "$cat1");
				//$newTopic->setAttribute($topicVal);
				$postContent = $dom->createElement('content', $theContent);
				
				
				$thePosts->item(0)->appendChild($newPost);
				$newPost->appendChild($postContent);
				
				
				$dom->save("$file");
				
				
				
				$rss = new rssFeed();
				$rss->loadFeed();
			
				
			}else {
				$sub2 .= '<p>Incorrect Entries or Password</p>';
				
			}
		
		}
		elseif(array_key_exists('submitNews',$_POST)){
			$sub2 .= '<p>Post not made. Make sure all fields are filled in.</p>';
		}
		$sub=<<<END
		
		<h3>Post News</h3>

		<form action = "/zto7115/539/project2/admin.php" method="post">

		<table>

		<tr>

			<td><input type="text" name="subjectNews" size="50" value="Subject or title" /></td>

		</tr>

		<tr>

			<td>

				<textarea style="font-size:18px;text-align:left;"  name="contentNews" rows="10" cols="80"></textarea>

			</td>

		</tr>

	</table>
	<div class="work">
	<strong>Password: </strong><input type="password" name="password2" size="15" /><br />

	<input type="reset" value="Reset Form" />

	<input type="submit" name="submitNews" value="Submit Form" />
	</div>
	</form>
	</div>



END;
		$sub .= $sub2;
		return $sub;
	}
	function sanitizeString($var) // Sanitizes the input string.
	{
			$var = trim($var);
			$var = stripslashes($var);
			$var = htmlentities($var);
			$var = strip_tags($var);
			return $var;
	}
	
	
	
		
	
	function endForm() //simply used to end a form tag
	{
		$string=<<<END
		
	</form>
	
END;
	}	
	
	
	/* The following is my Project 1 code for LIB_project
	<?php
	define('PASS','12345');
	function navigation() //this forms and creates the nav buttons common on every page
	{
		$string=<<<END
		
	<div class="menuBar">
	<a class="menuButton" href="index.php?1=1">Home</a>
	<a class="menuButton" href="news.php?1=1">News</a>
	<a class="menuButton" href="admin.php?1=1">Admin</a>
	
	</div>
	
END;
		return $string;
	}
	function chooseBanner($file='') // Argument $file takes in a file to be used
	{
		$f = file($file);
		foreach($f as $line) //read through each line in the file
		{
			list($pic,$count,$weight) = explode('|',$line);
			$banners[] = array('pic' => $pic, 'count' => $count, 'weight' => trim($weight));
		}
		foreach($banners as $key => $val) //populate the array
		{
			$picture[$key] = $val['pic'];
			$counter[$key] = $val['count'];
			$weighter[$key] = trim($val['weight']);
		}
		array_multisort($counter, SORT_ASC, $banners); //sort based on count ascending

		$banners[0]['count'] = $banners[0]['count'] + $banners[0]['weight'];
		$sub = '';
		for($i=0; $i<count($banners); $i++) 
		{
			$sub .= trim(implode('|',$banners[$i]));
			$sub .= "\n";

		}
		file_put_contents('banners.txt',$sub);
		return $banners[0]['pic']; //returns filepath for picture to be used.
	}
	
	function html_header($title="Untitled", $styles="") //creates the header with dynamic title and stylesheets
	{
		$string=<<<END
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>

	<title>$title</title>
	<link rel="stylesheet" href="$styles" type="text/css"  />
	
	</head>
	<body>
	
	
END;
		return $string; //returns the code that gets appended after most function calls, which creates the main php pages
	}
	function html_footer($text="") //creates the footer, with text being anything inputted when function is called.
	{
		$sub="";
	$sub .= '<div id="foot">';
	$sub .= '<p>';
	$sub .= $text;
	$sub .= '</p>';
	$ua = $_SERVER['HTTP_USER_AGENT'];
	
	
	if (stripos($ua, "Firefox")) { //if person is using firefox...
		$sub .= '<p>At least you use Firefox.</p>';
	} else {
		$sub .= '<p>not jumping on the Firefox bandwagon, huh?</p>';
	}
	if (stripos($ua, "Windows")) { //if using windows...
		$sub .= '<p>Ahhh, Windows. The superior OS.</p>';
	}
	if (stripos($ua, "Macintosh")) { //if using mac
		$sub .= '<p>LOL MAC USER!</p>';
	}
	if (stripos($ua, "Linux")) { //if using linux
		$sub .= 'echo "<p>People still use Linux?</p>"';
	}
	$sub .= '</div>';
	$sub .= '</body>';
	$sub .= '</html>';
	

		return $sub; //returns code to be placed in main php pages
	}
	
	function createBanner($pic="", $ad="") // takes picture and ad files and puts them into the Banner div
	{
		$string=<<<END
		
	
	<div id="bannerLogo">
	<img src="$pic" alt="Logo" />
	<div id="bannerAd"><img src="$ad" alt="ad"  /></div>
	</div>

	
END;
		return $string;
	}
	function createContent() //simply used to create the content div
	{
		$string=<<<END
		
	<div id="content">
	
END;
		return $string;
	}
	function createEditorial($pic="", $file="") //loads editorial picture and takes text from a file and inserts them into the editorial div
	{
		$sub = file_get_contents($file);
		$sub = nl2br($sub);
		$string=<<<END
		
	<div id="editorial">
	
	<p><img src="$pic" width="270" height="250" alt="Me" /></p>
	
	<p>
	$sub
	</p>
	
	</div>
	
END;
		return $string;
	}
	
	function createNews($display="", $file="", $page=1, $current="index") // $display is the number of items you want to display, and $file is the file it loads.
	{
		$f = file($file);
		$articles = $_GET[$page]-1;
		$articles = $articles*$display;
		
		$sub = '<div id="news">';
		
		
		foreach($f as $line) //separates the lines of the file into useful information
		{
			list($subject,$time,$body) = explode('|',$line);
			$newsArray[] = array('subj' => $subject, 'date' => $time, 'body' => $body);
			
		}
		$display = (count($newsArray)-$articles < $display) ? count($newsArray)-$articles : $display;
		foreach ($newsArray as $key => $row) 
		{
			$s[$key]  = $row['subj'];
			$t[$key] = $row['date'];
			$b[$key] = $row['body'];
		}
		$newsArray = array_reverse($newsArray); //to get the most current posts to display first
		for($i = 0; $i < $display; $i++) //cleans up and allows for line breaks, also creates the info
		{
			$amount = $articles + $i;
			$sub .= "<h2>" . $newsArray[$amount]['subj'] . "</h2>";
			$sub .= "<h4>" . $newsArray[$amount]['date'] . "</h4>";
			
			
			$clean = str_replace('&amp;lt;','<', $newsArray[$amount]['body']);
			$clean = str_replace('&amp;gt;','>', $clean);
			$clean = str_replace('&lt;','<', $clean);
			$clean = str_replace('&gt;','>', $clean);
			$clean = str_replace('&amp;quot;','"', $clean);
			$sub2 = nl2br("$clean");
			$sub .= "<p>" .  $sub2 . "</p>";
		}
		if($current == 'news') //if page is news
		{
			$pageNum = count($newsArray)/5;
			$round = ceil($pageNum);
			$sub .= '<p >';
			for($i=0;$i<$round;$i++) 
			{
				$i2 = $i+1;
				$sub .= '<a class="pageButtons" href="news.php?1=' . $i2 . '" >' . $i2 . '</a>';
			}
			$sub .= '</p>';
		}
		$sub .= '</div>';
	

		return $sub;
	} 
	
	function endContent() //simply ends the content div
	{
		$string=<<<END
		
	</div>
	
END;
		return $string;
	}
	
	function createEditForm($file="") //creates the Edit form on the admin page, $file is the file it writes to.
	{
		$sub=<<<END
		<div id="meh">
		<h2>Admin</h2>
		<h3>Edit Editorial</h3>
		<form action = "/zto7115/539/Project1/admin.php" method="post">

		<table>

			<tr>

				<td>

					<textarea style="font-size:18px;"  name="text" rows="10" cols="80"></textarea>

				</td>

			</tr>

		</table>

		
		<div class="work">
		<br />
		<strong>Password: </strong><input type="password" name="password1" size="15" /><br /><br />

		<input type="reset" value="Reset Form" />

		<input type="submit" name="submitEdit" value="Submit Changes" />
		</div>
		
		</form>

END;
		 
		
		
		
		
		if(isset($_POST['text']) && array_key_exists('submitEdit',$_POST) && strlen($_POST['text'])>0) //make sure all values are ok and fields filled in
		{
			
			if(constant("PASS") == $_POST['password1']) { //password is '12345'
				$theText = sanitizeString($_POST['text']);
				$sub .= "Your post has been made.";
				
				
			
				file_put_contents("$file", $theText);
			}else {
				$sub .= '<p>Incorrect Entries or Password</p>';
				
			}
		
		}
		elseif(array_key_exists('submitEdit',$_POST)) {
			$sub .= '<p>Post not made. Make sure all fields are filled in.</p>';
		}
	return $sub;
	}
	function createNewsForm($file="") // creates the news form, $file is the file it writes to
	{
		$sub=<<<END
		
		<h3>Post News</h3>

		<form action = "/zto7115/539/Project1/admin.php" method="post">

		<table>

		<tr>

			<td><input type="text" name="subjectNews" size="50" value="Subject or title" /></td>

		</tr>

		<tr>

			<td>

				<textarea style="font-size:18px;text-align:left;"  name="contentNews" rows="10" cols="80"></textarea>

			</td>

		</tr>

	</table>
	<div class="work">
	<strong>Password: </strong><input type="password" name="password2" size="15" /><br />

	<input type="reset" value="Reset Form" />

	<input type="submit" name="submitNews" value="Submit Form" />
	</div>
	</form>
	</div>



END;
		if(isset($_POST['contentNews']) && isset($_POST['subjectNews'])&& array_key_exists('submitNews',$_POST) && strlen($_POST['subjectNews'])>0 && strlen($_POST['contentNews'])>0) 
		{
			
			if(constant("PASS") == $_POST['password2']) {
				$time=time();

				
				$theText  = sanitizeString($_POST['subjectNews']) . '|';
				
				$theText .= date("F j, Y, g:i a", $time) . '|';
				$clean = sanitizeString($_POST['contentNews']) ;
				$clean = str_replace(chr(10), '<br />', $clean); //to help deal with line breaks
				$clean = str_replace(chr(13), '<br />', $clean);
				$theText .= sanitizeString($clean) . chr(10);
				$sub .= "Your post has been made.";
				
				
			
				file_put_contents("$file", $theText, FILE_APPEND); //writes to selected file
			}else {
				$sub .= '<p>Incorrect Entries or Password</p>';
				
			}
		
		}
		elseif(array_key_exists('submitNews',$_POST)){
			$sub .= '<p>Post not made. Make sure all fields are filled in.</p>';
		}
		return $sub;
	}
	function sanitizeString($var) // Sanitizes the input string.
	{
			$var = trim($var);
			$var = stripslashes($var);
			$var = htmlentities($var);
			$var = strip_tags($var);
			return $var;
	}
	
	
	
		
	
	function endForm() //simply used to end a form tag
	{
		$string=<<<END
		
	</form>
	
END;
	}	


?>
	
	
	
	
	*/

?>