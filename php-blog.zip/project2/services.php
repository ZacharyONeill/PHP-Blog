<?php
	require_once 'LIB_project1.php';
	

	$string = '';
	$string .= html_header($title='The Daily Annual - Services' , $styles='style.css');
	$picture = chooseBanner($file='banners.txt');
	
	$string .= createBanner($pic='./pictures/newspaper.jpg', $ad="$picture");
	$string .= navigation();
	$string .= createContent();
	
	$string .= "<h3><a  href='http://people.rit.edu/zto7115/539/project2/project2.rss'>My RSS Feed</a></h3>";

	
	
	$utilClass = new p2_utils();
	$string .= $utilClass->displayClassmates($file = 'rss_class.xml');
	
	$string .= endContent();
	$string .= html_footer($text='Lets see what you like to use...');
	echo $string;







?>