<?php

require_once 'LIB_project1.php';
$string = '';
$string .= html_header($title='The Daily Annual - News' , $styles='style.css');
$picture = chooseBanner($file='banners.txt');
$string .= createBanner($pic='./pictures/newspaper.jpg', $ad="$picture");
$string .= navigation();
$string .= createContent();

$string .= createNews($display='5', $file='news.xml', $page=1, $current='news');
$string .= endContent();
$string .= html_footer($text='And here is the footer');
echo $string;


/* The following is the code from project1 for news.php
	<?php

	require_once 'LIB_project1.php';
	$string = '';
	$string .= html_header($title='The Daily Annual - News' , $styles='style.css');
	$picture = chooseBanner($file='banners.txt');
	$string .= createBanner($pic='./pictures/newspaper.jpg', $ad="$picture");
	$string .= navigation();
	$string .= createContent();

	$string .= createNews($display='5', $file='news.txt', $page=1, $current='news');
	$string .= endContent();
	$string .= html_footer($text='And here is the footer');
	echo $string;
	?>







*/
?>