<?php

require_once 'LIB_project1.php';
$string = '';
$string .= html_header($title='The Daily Annual' , $styles='style.css');
$picture = chooseBanner($file='banners.txt');

$string .= createBanner($pic='./pictures/newspaper.jpg', $ad="$picture");
$string .= navigation();
$string .= createContent();

$string .= createNews($display='3', $file='news.xml');
$string .= createEditorial($pic='./pictures/Zach.jpg', $file='editorial.xml');


$string .= endContent();
$utilClass = new p2_utils();
$string .= $utilClass->displayServices();

$string .= html_footer($text='Lets see what you like to use...');
echo $string;

	/* the following is the code from Project1 for index.php
	<?php

	require_once 'LIB_project1.php';
	$string = '';
	$string .= html_header($title='The Daily Annual' , $styles='style.css');
	$picture = chooseBanner($file='banners.txt');

	$string .= createBanner($pic='./pictures/newspaper.jpg', $ad="$picture");
	$string .= navigation();
	$string .= createContent();
	$string .= createEditorial($pic='./pictures/Zach.jpg', $file='editorial.txt');
	$string .= createNews($display='3', $file='news.txt');

	$string .= endContent();
	$string .= html_footer($text='Lets see what you like to use...');
	echo $string;
	?>
	
	
	
	
	*/
?>